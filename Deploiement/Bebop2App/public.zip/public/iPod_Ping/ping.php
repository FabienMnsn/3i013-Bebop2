<?php


$port = "1234";
$sdp_name = "video_stream.sdp";
$curr_ip_file = "current_ip.txt";

if(isset($_GET["action"])){
	$action = htmlspecialchars($_GET["action"]);
	switch($action){
		case "ping" ://on répond au ping de l'iPod
	
			$ip = $_SERVER['REMOTE_ADDR'];//ip du client

			//maj des logs :
			$monfichier = fopen("logs.txt", 'a');
			$date = date('m/d/Y h:i:s a', time());
		  	$content = $ip." ping: [ ".$date." ]\r\n";
			fputs($monfichier, $content);
			fclose($monfichier);

			echo "OK";
			break; 

		case "connect":
			$ip = $_SERVER['REMOTE_ADDR'];//ip du client

			//maj de l'ip courrante
			unlink($curr_ip_file);
			$ipFile = fopen($curr_ip_file, 'a');//on enregistre l'ip du client
			fputs($ipFile, $ip);
			fclose($ipFile);
			echo "Connected";
			break;

		case "getSDP":
			$ip = $_SERVER['REMOTE_ADDR'];//ip du client
			unlink($sdp_name);
			$sdp = fopen($sdp_name, 'a+');
		  	$content = "v=0\r\no=- 0 0 IN IP4 127.0.0.1\r\ns=No Name\r\nc=IN IP4 ".$ip."\r\nt=0 0\r\na=tool:libavformat 56.40.101\r\nm=video ".$port." RTP/AVP 96\r\na=rtpmap:96 H264/90000\r\na=fmtp:96 packetization-mode=1\r\n";
			fputs($sdp, $content);
			fclose($sdp);
			echo "done :".$ip;
			break;

		case "reset"://initialisation des fichiers pour le vol du drone (doit être fait avant le lancement du programme du drone ou après)
			//on flush les fichiers de signalement (start/stop):
			unlink("stop.txt");
			$stopFile = fopen("stop.txt", 'a');
			fclose($stopFile);
			unlink("start.txt");
			$startFile = fopen("start.txt", 'a');
			fclose($startFile);
			echo "reset done";
			break;

		case "start"://démarrage du plan de vol du drone

			//on écris dans le fichier pour signaler que le drone doit décoller
			unlink("start.txt");
			$startFile = fopen("start.txt", 'a');
			fputs($startFile, "s");
			fclose($startFile);

			echo "started"; 
			break;

		case "stop": //arrêt d'urgence du drone

			//on écris dans le fichier pour signaler que le drone doit décoller
			unlink("stop.txt");
			$stopFile = fopen("stop.txt", 'a');
			fputs($stopFile, "s");
			fclose($stopFile);

			echo "stoped"; 
			break;

		default:
			echo "invalid parameters";
			break;
	}

	
}
else{
	echo "invalid parameters";
}




?>
