//
//  ViewController.swift
//  webLoad
//
//  Created by m2sar on 27/03/2019.
//  Copyright © 2019 m2sar. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController, WKUIDelegate{

    @IBOutlet weak var myWebview: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let myURL = URL(string:"https://www.apple.com")
        let myRequest = URLRequest(url: myURL!)
        myWebview.load(myRequest)    }


}

